import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

import "./App.css";
import Home from "./pages/Home";
import GenerateQR from "./pages/GenerateQR";
import FoodCategory from "./pages/FoodCategory";
import Pos from "./pages/Pos";
import Table from "./pages/Table";
import UnderPos from "./pages/UnderPos";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/pos" element={<Pos />} />
        <Route path="/generate-qr" element={<GenerateQR />} />
        <Route path="/food-category" element={<FoodCategory />} />
        <Route path="/table" element={<Table />} />
        <Route path="/under-pos" element={<UnderPos />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
