import React, { useRef, useState } from "react";
import Header from "../components/Header";
import { Col, Container, Row, Form, Modal, InputGroup } from "react-bootstrap";
import {
  Banknote,
  Check,
  ChevronLeft,
  ChevronRight,
  CreditCard,
  Landmark,
  Minus,
  Plus,
  ScanLine,
  Search,
  SquareDashedPlus,
  X,
} from "lucide-react";

import categoryImage from "../assets/images/cate-1.jpg";
import categoryImage2 from "../assets/images/cate-2.jpg";
import categoryImage3 from "../assets/images/cate-3.jpg";
import categoryImage4 from "../assets/images/cate-4.jpg";

const foodItems = [
  {
    id: 1,
    name: "Chicken Reshmi Kebab",
    price: 999,
    category: "Main Courses",
    image: categoryImage,
  },
  {
    id: 2,
    name: "Paneer Tikka",
    price: 249,
    category: "Appetizers",
    image: categoryImage2,
  },
  {
    id: 3,
    name: "Chicken Biryani",
    price: 299,
    category: "Main Courses",
    image: categoryImage3,
  },
  {
    id: 4,
    name: "Veg Hakka Noodles",
    price: 189,
    category: "Chinese Snacks",
    image: categoryImage4,
  },
  {
    id: 5,
    name: "Butter Chicken",
    price: 349,
    category: "Main Courses",
    image: categoryImage2,
  },
  {
    id: 6,
    name: "Masala Dosa",
    price: 149,
    category: "Fast Food",
    image: categoryImage3,
  },
  {
    id: 7,
    name: "Tandoori Chicken",
    price: 399,
    category: "Appetizers",
    image: categoryImage,
  },
  {
    id: 8,
    name: "Mutton Biryani",
    price: 379,
    category: "Main Courses",
    image: categoryImage4,
  },
  {
    id: 9,
    name: "Chilli Paneer",
    price: 229,
    category: "Chinese Snacks",
    image: categoryImage2,
  },
  {
    id: 10,
    name: "Chicken Momos",
    price: 169,
    category: "Chinese Snacks",
    image: categoryImage3,
  },
  {
    id: 11,
    name: "Fish Finger",
    price: 279,
    category: "Appetizers",
    image: categoryImage4,
  },
  {
    id: 12,
    name: "Margherita Pizza",
    price: 299,
    category: "Fast Food",
    image: categoryImage,
  },
  {
    id: 13,
    name: "Chicken Burger",
    price: 199,
    category: "Fast Food",
    image: categoryImage2,
  },
  {
    id: 14,
    name: "French Fries",
    price: 129,
    category: "Fast Food",
    image: categoryImage3,
  },
  {
    id: 15,
    name: "Chocolate Brownie",
    price: 149,
    category: "Desserts",
    image: categoryImage4,
  },
  {
    id: 16,
    name: "Cold Coffee",
    price: 119,
    category: "Drinks",
    image: categoryImage,
  },
];

function CustomLeftArrow({ onClick }) {
  return (
    <button
      type="button"
      className="pos-carousel-arrow pos-carousel-prev"
      onClick={onClick}
      aria-label="Scroll categories left"
    >
      <ChevronLeft size={20} />
    </button>
  );
}

function CustomRightArrow({ onClick }) {
  return (
    <button
      type="button"
      className="pos-carousel-arrow pos-carousel-next"
      onClick={onClick}
      aria-label="Scroll categories right"
    >
      <ChevronRight size={20} />
    </button>
  );
}

function UnderPos() {
  const categoryListRef = useRef(null);

  const [show, setShow] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState("Paid");
  const [paymentMethod, setPaymentMethod] = useState("Card");
  const [billType, setBillType] = useState("1");
  const [mobileNumber, setMobileNumber] = useState("");
  const [customerName, setCustomerName] = useState("");
  const [splitPayment, setSplitPayment] = useState(false);
  const [splitPaymentMethod, setSplitPaymentMethod] = useState("Cash");
  const [splitAmount, setSplitAmount] = useState("");

  const handleClose = () => setShow(false);

  const handleShow = () => {
    if (cartItems.length === 0) {
      alert("Please add food items before checkout.");
      return;
    }

    setShow(true);
  };

  const [activeCategory, setActiveCategory] = useState("All");
  const [searchTerm, setSearchTerm] = useState("");
  const [quantities, setQuantities] = useState({});
  const [cartItems, setCartItems] = useState([]);
  const [discount, setDiscount] = useState("");
  const [discountType, setDiscountType] = useState("1");

  const categories = [
    { name: "Fast Food", qty: 10, image: categoryImage },
    { name: "Drinks", qty: 15, image: categoryImage2 },
    { name: "Desserts", qty: 8, image: categoryImage3 },
    { name: "Appetizers", qty: 12, image: categoryImage4 },
    { name: "Main Courses", qty: 20, image: categoryImage },
    { name: "Chinese Snacks", qty: 20, image: categoryImage2 },
  ];

  const scrollCategories = (direction) => {
    const categoryList = categoryListRef.current;
    if (!categoryList) return;

    categoryList.scrollBy({
      left: direction * categoryList.clientWidth * 0.8,
      behavior: "smooth",
    });
  };

  const filteredFoodItems = foodItems.filter((food) => {
    const matchesCategory =
      activeCategory === "All" || food.category === activeCategory;

    const matchesSearch = food.name
      .toLowerCase()
      .includes(searchTerm.toLowerCase());

    return matchesCategory && matchesSearch;
  });

  const updateQuantity = (foodId, change) => {
    setQuantities((prev) => ({
      ...prev,
      [foodId]: Math.max(1, (prev[foodId] || 1) + change),
    }));
  };

  const addFoodToCart = (food) => {
    const selectedQuantity = quantities[food.id] || 1;

    setCartItems((prev) => {
      const existingItem = prev.find((item) => item.id === food.id);

      if (existingItem) {
        return prev.map((item) =>
          item.id === food.id
            ? { ...item, qty: item.qty + selectedQuantity }
            : item,
        );
      }

      return [
        ...prev,
        {
          ...food,
          qty: selectedQuantity,
        },
      ];
    });

    setQuantities((prev) => ({
      ...prev,
      [food.id]: 1,
    }));
  };

  const removeFoodFromCart = (foodId) => {
    setCartItems((prev) => prev.filter((item) => item.id !== foodId));
  };

  const subtotal = cartItems.reduce(
    (total, item) => total + item.price * item.qty,
    0,
  );

  const tax = Math.round(subtotal * 0.05);
  const donation = cartItems.length > 0 ? 1 : 0;

  const discountAmount = Math.min(
    subtotal + tax + donation,
    Math.max(
      0,
      discountType === "2"
        ? (subtotal * (Number(discount) || 0)) / 100
        : Number(discount) || 0,
    ),
  );

  const totalPayable = Math.max(0, subtotal + tax + donation - discountAmount);

  const handleCancel = () => {
    setCartItems([]);
    setDiscount("");
    setDiscountType("1");
    setQuantities({});
  };

  const resetBillingForm = () => {
    setBillType("1");
    setMobileNumber("");
    setCustomerName("");
    setPaymentStatus("Paid");
    setPaymentMethod("Card");
    setSplitPayment(false);
    setSplitPaymentMethod("Cash");
    setSplitAmount("");
  };

  const handleBillingSubmit = (e) => {
    e.preventDefault();

    if (cartItems.length === 0) {
      alert("Please add food items before checkout.");
      handleClose();
      return;
    }

    if (!mobileNumber.trim()) {
      alert("Please enter mobile number.");
      return;
    }

    if (!customerName.trim()) {
      alert("Please enter customer name.");
      return;
    }

    if (splitPayment) {
      const secondAmount = Number(splitAmount);

      if (!splitAmount || secondAmount <= 0 || secondAmount >= totalPayable) {
        alert("Please enter a valid split payment amount.");
        return;
      }
    }

    const billingDetails = [
      "Billing completed successfully!",
      `Customer: ${customerName}`,
      `Mobile: ${mobileNumber}`,
      `Total Payable: ₹${totalPayable.toFixed(2)}`,
      `Payment Method: ${paymentMethod}`,
    ];

    if (splitPayment) {
      billingDetails.push(
        `First Payment: ₹${(totalPayable - Number(splitAmount)).toFixed(2)} (${paymentMethod})`,
        `Second Payment: ₹${Number(splitAmount).toFixed(2)} (${splitPaymentMethod})`,
      );
    }

    alert(billingDetails.join("\n"));

    handleCancel();
    handleClose();
    resetBillingForm();
  };

  return (
    <>
      <Header />

      <main className="restonest-dashboard pos-page">
        <Container fluid>
          <div className="dashboard-stat-card">
            <Row>
              <Col md="9">
                <div className="point-of-sale-wrapper">
                  <div className="pos-carousel-container">
                    <CustomLeftArrow onClick={() => scrollCategories(-1)} />

                    <div className="pos-carousel-list" ref={categoryListRef}>
                      <div
                        className={`pos-carousel-item ${
                          activeCategory === "All" ? "active" : ""
                        }`}
                        onClick={() => setActiveCategory("All")}
                        role="button"
                        tabIndex={0}
                        onKeyDown={(e) =>
                          e.key === "Enter" && setActiveCategory("All")
                        }
                      >
                        <div className="pos-category-item">
                          <div className="pos-item-image">
                            <img
                              src={categoryImage}
                              alt="All Food"
                              draggable="false"
                            />
                          </div>

                          <div className="pos-name">All Food</div>

                          <div className="pos-qty">{foodItems.length}</div>
                        </div>
                      </div>

                      {categories.map((category, index) => (
                        <div
                          className={`pos-carousel-item ${
                            activeCategory === category.name ? "active" : ""
                          }`}
                          key={index}
                          onClick={() => setActiveCategory(category.name)}
                          role="button"
                          tabIndex={0}
                          onKeyDown={(e) =>
                            e.key === "Enter" &&
                            setActiveCategory(category.name)
                          }
                        >
                          <div className="pos-category-item">
                            <div className="pos-item-image">
                              <img
                                src={category.image}
                                alt={category.name}
                                draggable="false"
                              />
                            </div>

                            <div className="pos-name">{category.name}</div>

                            <div className="pos-qty">
                              {
                                foodItems.filter(
                                  (food) => food.category === category.name,
                                ).length
                              }
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    <CustomRightArrow onClick={() => scrollCategories(1)} />
                  </div>
                </div>

                <div className="pos-food-wrapper">
                  <div className="pos-food-inner">
                    <Row>
                      {filteredFoodItems.length > 0 ? (
                        filteredFoodItems.map((food) => {
                          const isAdded = cartItems.some(
                            (item) => item.id === food.id,
                          );

                          return (
                            <Col
                              md={3}
                              xl={2}
                              xs={6}
                              className="mb-3"
                              key={food.id}
                            >
                              <div className="pos-food-item">
                                <div className="pos-food-image">
                                  <img
                                    src={food.image}
                                    alt={food.name}
                                    draggable="false"
                                    className="img-fluid"
                                  />
                                </div>

                                <div className="pos-food-details">
                                  <h6>{food.name}</h6>

                                  <div className="pos-price">
                                    <p>₹{food.price}</p>

                                    <div className="pos-count">
                                      <button
                                        type="button"
                                        className="pos-decrement"
                                        onClick={() =>
                                          updateQuantity(food.id, -1)
                                        }
                                        disabled={
                                          (quantities[food.id] || 1) <= 1
                                        }
                                        aria-label="Decrease quantity"
                                      >
                                        <Minus size={12} />
                                      </button>

                                      <div className="pos-count-value">
                                        {quantities[food.id] || 1}
                                      </div>

                                      <button
                                        type="button"
                                        className="pos-increment"
                                        onClick={() =>
                                          updateQuantity(food.id, 1)
                                        }
                                        aria-label="Increase quantity"
                                      >
                                        <Plus size={12} />
                                      </button>
                                    </div>
                                  </div>
                                </div>

                                <div className="pos-food-btn">
                                  <button
                                    type="button"
                                    className={`btn btn-food-add ${
                                      isAdded ? "added" : ""
                                    }`}
                                    onClick={() => addFoodToCart(food)}
                                    aria-label={`Add ${food.name}`}
                                  >
                                    {isAdded ? (
                                      <Check size={16} />
                                    ) : (
                                      <Plus size={16} />
                                    )}
                                  </button>
                                </div>
                              </div>
                            </Col>
                          );
                        })
                      ) : (
                        <Col xs={12}>
                          <p className="text-center py-4">
                            No food items found.
                          </p>
                        </Col>
                      )}
                    </Row>
                  </div>
                </div>
              </Col>

              <Col md="3">
                <div className="search-wrapper">
                  <Form.Group>
                    <Form.Control
                      placeholder="Search products...."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                    <Search size={18} />
                  </Form.Group>
                </div>

                <div className="pos-order-wrapper">
                  <div className="pos-order-content">
                    <div className="pos-right-method mb-2 header">
                      <Form>
                        <div className="d-flex gap-2 mb-2">
                          <Form.Group>
                            <Form.Select aria-label="Order status">
                              <option value="1">On Dine</option>
                              <option value="2">Reserved</option>
                              <option value="3">Available</option>
                            </Form.Select>
                          </Form.Group>

                          <Form.Group>
                            <Form.Select aria-label="Select table">
                              <option value="1">Table 1 (Available)</option>
                              <option value="2">Table 2 (Available)</option>
                              <option value="3">Table 3 (Available)</option>
                            </Form.Select>
                          </Form.Group>
                        </div>

                        <Form.Group>
                          <Form.Control
                            required
                            type="text"
                            defaultValue="Rajkumar Laha"
                          />
                        </Form.Group>
                      </Form>
                    </div>

                    <div className="pos-order-body">
                      <div className="pos-order-section">
                        <div className="pos-order-heading mb-3">
                          <h6>Ordered Items</h6>

                          <span>
                            {cartItems
                              .reduce((total, item) => total + item.qty, 0)
                              .toString()
                              .padStart(2, "0")}
                          </span>
                        </div>

                        <div className="pos-ordered-list">
                          {cartItems.length > 0 ? (
                            cartItems.map((item) => (
                              <div className="pos-ordered-item" key={item.id}>
                                <span>{item.qty}x</span>

                                <p>{item.name}</p>

                                <strong>
                                  ₹{(item.price * item.qty).toFixed(2)}
                                </strong>

                                <button
                                  type="button"
                                  className="pos-ordered-remove"
                                  onClick={() => removeFoodFromCart(item.id)}
                                  aria-label={`Remove ${item.name}`}
                                >
                                  <X size={10} />
                                </button>
                              </div>
                            ))
                          ) : (
                            <p className="text-center py-3 empty-cart-message">
                              <SquareDashedPlus size={20} />
                              <br />
                              No items added yet.
                            </p>
                          )}
                        </div>
                      </div>

                      <div className="pos-payment-summary">
                        <h6>Payment Summary</h6>

                        <div className="pos-summary-row">
                          <span>Subtotal</span>
                          <strong>₹{subtotal.toFixed(2)}</strong>
                        </div>

                        <div className="pos-summary-row">
                          <span>Tax (5%)</span>
                          <strong>₹{tax.toFixed(2)}</strong>
                        </div>

                        <div className="pos-summary-row">
                          <span>Donation for Palestine</span>
                          <strong>₹{donation.toFixed(2)}</strong>
                        </div>

                        {discountAmount > 0 && (
                          <div className="pos-summary-row">
                            <span>Discount</span>
                            <strong>-₹{discountAmount.toFixed(2)}</strong>
                          </div>
                        )}

                        <div className="pos-total-row">
                          <strong>Total Payable</strong>
                          <strong>₹{totalPayable.toFixed(2)}</strong>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="pos-order-actions footer">
                    <div className="pos-right-method mt-2">
                      <h6>Discount</h6>

                      <Form>
                        <div className="d-flex gap-2">
                          <Form.Group>
                            <Form.Select
                              value={discountType}
                              onChange={(e) => setDiscountType(e.target.value)}
                            >
                              <option value="1">Flat</option>
                              <option value="2">Percentage</option>
                            </Form.Select>
                          </Form.Group>
                          <Form.Group>
                            <Form.Control
                              type="number"
                              min="0"
                              placeholder="Discount"
                              value={discount}
                              onChange={(e) => setDiscount(e.target.value)}
                            />
                          </Form.Group>
                        </div>
                      </Form>
                    </div>

                    <div className="d-flex gap-2 mb-2">
                      <button
                        type="button"
                        className="resto-primary w-100"
                        onClick={handleCancel}
                      >
                        Cancel
                      </button>

                      <button
                        type="button"
                        className="resto-secondary w-100"
                        onClick={handleShow}
                      >
                        Checkout
                      </button>
                    </div>
                  </div>
                </div>
              </Col>
            </Row>
          </div>
        </Container>

        <Modal
          show={show}
          onHide={handleClose}
          dialogClassName="billing-modal-right"
        >
          <Form onSubmit={handleBillingSubmit}>
            <Modal.Header closeButton>
              <Modal.Title>Billing Info</Modal.Title>
            </Modal.Header>

            <Modal.Body>
              <InputGroup className="mb-3">
                <InputGroup.Text>Bill Type</InputGroup.Text>
                <Form.Select
                  value={billType}
                  onChange={(e) => setBillType(e.target.value)}
                >
                  <option value="1">One</option>
                  <option value="2">Two</option>
                  <option value="3">Three</option>
                </Form.Select>
              </InputGroup>

              <InputGroup className="mb-3">
                <InputGroup.Text>Mob No</InputGroup.Text>
                <Form.Control
                  type="tel"
                  placeholder="Enter mobile number"
                  aria-label="Mobile number"
                  value={mobileNumber}
                  onChange={(e) => setMobileNumber(e.target.value)}
                  required
                />
              </InputGroup>

              <InputGroup className="mb-3">
                <InputGroup.Text>Customer Name</InputGroup.Text>
                <Form.Control
                  type="text"
                  placeholder="Enter customer name"
                  aria-label="Customer Name"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  required
                />
              </InputGroup>

              <div className="mt-3 mb-3">
                <h5>Payment Method</h5>

                <div className="pos-payment-method">
                  <button
                    type="button"
                    className={paymentMethod === "Cash" ? "active" : ""}
                    onClick={() => setPaymentMethod("Cash")}
                  >
                    <Banknote size={16} />
                    <span>Cash</span>
                  </button>

                  <button
                    type="button"
                    className={paymentMethod === "Card" ? "active" : ""}
                    onClick={() => setPaymentMethod("Card")}
                  >
                    <CreditCard size={16} />
                    <span>Card</span>
                  </button>

                  <button
                    type="button"
                    className={paymentMethod === "Online" ? "active" : ""}
                    onClick={() => setPaymentMethod("Online")}
                  >
                    <ScanLine size={16} />
                    <span>Online</span>
                  </button>

                  <button
                    type="button"
                    className={paymentMethod === "NetBanking" ? "active" : ""}
                    onClick={() => setPaymentMethod("NetBanking")}
                  >
                    <Landmark size={16} />
                    <span>Net banking</span>
                  </button>
                </div>
              </div>

              <InputGroup className="mb-3">
                <InputGroup.Text>Payable Amount</InputGroup.Text>
                <Form.Control
                  type="text"
                  value={`₹${totalPayable.toFixed(2)}`}
                  aria-label="Payable Amount"
                  readOnly
                />
              </InputGroup>

              {splitPayment && (
                <div className="split-payment-fields">
                  <div className="d-flex align-items-center justify-content-between">
                    <h5 class="qr-header">
                      <div class="dot" bis_skin_checked="1"></div>Split Payment
                    </h5>
                    <button
                      type="button"
                      className="pos-ordered-remove"
                      onClick={() => {
                        setSplitPayment(false);
                        setSplitAmount("");
                      }}
                    >
                      <X size={10} />
                    </button>
                  </div>
                  <Row>
                    <Col md={6}>
                      <Form.Group className="mb-3" controlId="tableNumber">
                        <Form.Label>Second Amount</Form.Label>
                        <Form.Control
                          type="number"
                          min="0.01"
                          max={Math.max(0, totalPayable - 0.01)}
                          step="0.01"
                          placeholder="Enter amount"
                          value={splitAmount}
                          onChange={(e) => setSplitAmount(e.target.value)}
                          required
                        />
                      </Form.Group>
                    </Col>
                    <Col md={6}>
                      <Form.Group className="mb-3" controlId="tableNumber">
                        <Form.Label>Second Method</Form.Label>
                        <Form.Select
                          value={splitPaymentMethod}
                          onChange={(e) =>
                            setSplitPaymentMethod(e.target.value)
                          }
                        >
                          <option value="Cash">Cash</option>
                          <option value="Card">Card</option>
                          <option value="Online">Online</option>
                          <option value="NetBanking">Net banking</option>
                        </Form.Select>
                      </Form.Group>
                    </Col>
                  </Row>

                  {Number(splitAmount) > 0 &&
                    Number(splitAmount) < totalPayable && (
                      <div className="pos-summary-row mb-3">
                        <span>Remaining Amount</span>
                        <strong>
                          ₹{(totalPayable - Number(splitAmount)).toFixed(2)}
                        </strong>
                      </div>
                    )}
                </div>
              )}
            </Modal.Body>

            <Modal.Footer>
              <button
                type="button"
                className="resto-secondary"
                onClick={() => {
                  setSplitPayment((prev) => !prev);
                  setSplitAmount("");
                }}
              >
                {splitPayment ? "Remove Split Payment" : "Add Split Payment"}
              </button>

              <button
                type="button"
                className="resto-cancel"
                onClick={handleClose}
              >
                Cancel
              </button>

              <button className="resto-primary" type="submit">
                Submit
              </button>
            </Modal.Footer>
          </Form>
        </Modal>
      </main>
    </>
  );
}

export default UnderPos;
